
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Clases grabadas</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">                        
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-course')): ?>
                                <a class="btn btn-warning" href="<?php echo e(route('courses.create')); ?>">Nuevo</a>
                            <?php endif; ?>
                
                            <table class="table table-striped mt-2">
                                <thead style="background-color:#6777ef">                                     
                                    <th style="display: none;">ID</th>
                                    <th style="color:#fff;">Titulo</th>
                                    <th style="color:#fff;">Video</th>
                                    <th style="color:#fff;">Tipo</th>                               
                                    <th style="color:#fff;">Acciones</th>                                                                   
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td style="display: none;"><?php echo e($course->id); ?></td>                                
                                            <td><?php echo e($course->title); ?></td>
                                            <td><?php echo e($course->video); ?></td>
                                            <td><h5><span class="badge badge-warning"><?php echo e($course->tipo); ?></span></h5></td>
                                            
                                            <td>
                                                <form action="<?php echo e(route('courses.destroy',$course->id)); ?>" method="POST">                                        
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-course')): ?>
                                                        <a class="btn btn-info" href="<?php echo e(route('courses.edit',$course->id)); ?>">Editar</a>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-course')): ?>
                                                        <a class="btn btn-success" href="<?php echo e(route('courses.show',$course->id)); ?>">Ver</a>
                                                    <?php endif; ?>
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-course')): ?>
                                                        <button type="submit" class="btn btn-danger">Borrar</button>
                                                    <?php endif; ?>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                            <!-- Ubicamos la paginacion a la derecha -->
                            <div class="pagination justify-content-end">
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script>
    <script type="text/javascript">
        $('#description').summernote({
            height: 200
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppNew\htdocs\Importaciones\resources\views/courses/index.blade.php ENDPATH**/ ?>