<li class="side-menus <?php echo e(Request::is('*') ? 'active' : ''); ?>">
    <a class="nav-link" href="/dashboard">
        <i class=" fas fa-building"></i><span>Dashboard</span>
    </a>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-user')): ?>
        <a class="nav-link" href="/users">
            <i class=" fas fa-users"></i><span>Usuarios</span>
        </a>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-rol')): ?>
        <a class="nav-link" href="/roles">
            <i class=" fas fa-user-lock"></i><span>Roles</span>
        </a>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-course')): ?>
        <a class="nav-link" href="/courses">
            <i class=" fas fa-school"></i><span>Clases grabadas</span>
        </a>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-asesoria')): ?>
            <a class="nav-link" href="/asesorias">
                <i class=" fas fa-laptop-code"></i><span>Gestionar Asesoria</span>
            </a>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-anexo')): ?>
            <a class="nav-link" href="/anexos">
                <i class=" fas fa-file"></i><span>Material de clases</span>
            </a>        
        <?php endif; ?>
        <a class="nav-link" href="/calculadora" target="_blank">
            <i class=" fas fa-calculator"></i><span>Calculadora</span>
        </a>
        
    <?php endif; ?>
</li>
<?php /**PATH C:\xamppNew\htdocs\Importaciones\resources\views/layouts/menu.blade.php ENDPATH**/ ?>