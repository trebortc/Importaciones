

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h5 class="page__heading">EDITAR CURSO</h5>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">                            
                   
                        <?php if($errors->any()): ?>                                                
                            <div class="alert alert-dark alert-dismissible fade show" role="alert">
                            <strong>¡Revise los campos!</strong>                        
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                    
                                    <span class="badge badge-danger"><?php echo e($error); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                        
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            </div>
                        <?php endif; ?>


                    <form action="<?php echo e(route('courses.update',$course->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                   <label for="title">Título</label>
                                   <input type="text" name="title" class="form-control" value="<?php echo e($course->title); ?>">
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                   <label for="video">Video</label>
                                   <input type="text" name="video" class="form-control" value="<?php echo e($course->video); ?>">
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-12">                                                
                                <div class="form-floating">
                                    <label for="description">Descripción</label>
                                    <textarea class="form-control" name="description" id="description"><?php echo e($course->description); ?></textarea>                                
                                </div>                                                      
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-12">                                                
                                <div class="form-group">
                                    <label for="tipo">Tipo contenido</label>
                                    <select class="form-control" value="<?php echo e($course->tipo); ?>" name="tipo">
                                        <option value="Clase">Clase</option>        
                                        <option value="Asesoria">Asesoria</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-12"><br/>
                                <button type="submit" class="btn btn-primary">Guardar</button>
                            </div>
                        </div>
                    </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script>
    <script type="text/javascript">
        $('#description').summernote({
            height: 200
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppNew\htdocs\importaciones8\resources\views/courses/edit.blade.php ENDPATH**/ ?>