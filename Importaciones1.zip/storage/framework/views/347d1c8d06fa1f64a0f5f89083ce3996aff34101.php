

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h5 class="page__heading"><?php echo e($course->tipo); ?></h5>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">                                            
                        <div class="embed-responsive embed-responsive-16by9">
                            
                            
                            <iframe src="<?php echo e($course->video); ?>" allow="autoplay"></iframe>
                        </div>
                        
                        <div class="card-body">                                                
                            <h4 class="card-title"><?php echo e($course->title); ?></h4>
                            
                            
                            <textarea class="card-text" name="description" id="description"><?php echo e($course->description); ?></textarea>                              
                            <br/>
                            
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script>
    <script type="text/javascript">
        $('#description').summernote({
            height: 200
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppNew\htdocs\importaciones8\resources\views/courses/show.blade.php ENDPATH**/ ?>