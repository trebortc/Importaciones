@extends('layouts.app')

@section('content')
    <section class="section">
        <div class="section-header">
            <h5 class="page__heading">ADMINISTRAR ASESORÍAS</h5>
        </div>
        <div class="section-body">
            <div class="row">
                sadsads               
            </div>
        </div>
    </section>
@endsection

